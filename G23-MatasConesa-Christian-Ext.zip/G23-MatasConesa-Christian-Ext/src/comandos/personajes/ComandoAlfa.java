package comandos.personajes;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import comandos.estructura.Direccion;

public class ComandoAlfa extends Comando implements Cloneable{

	public ComandoAlfa(int numBombas) {
		super(numBombas);
	}

	public boolean lanzarBomba() {
		if (getEscenario().tieneVentana(getPosActual().getX(), getPosActual().getY()) && getBombasDisponibles() > 0 && getPosActual().getY() < 5) {
			bombasDisponibles--;
			getEscenario().liberarBomba(getPosActual());
			return true;
		} else {
			return false;
		}
	}

	public Direccion movimiento() {
		List<Direccion> p = getEscenario().posiblesDirecciones(getPosActual().getX(), getPosActual().getY());
		LinkedList<Direccion> posiblesDirecciones = new LinkedList<>(p); 
		for (Direccion direccion : posiblesDirecciones) {
			if (direccion.equals(Direccion.ABAJO)) {
				return direccion;
				
			}
		}
		Random r = new Random();
		int random = r.nextInt(posiblesDirecciones.size());
		Direccion dir = null;
		for (int i = 0; i < posiblesDirecciones.size(); i++) {
			if (random == i) {
				dir = posiblesDirecciones.get(i);
				return dir;
			}
		}
		return null;
		
	}
	
	@Override
	public ComandoAlfa clone() {
		ComandoAlfa copia = (ComandoAlfa) super.clone();
		copia.bombasDisponibles = 3;
		return copia;
		
	}

	public String getRuta() {
		return "imagenes/comando-alfa.png";
	}

}
