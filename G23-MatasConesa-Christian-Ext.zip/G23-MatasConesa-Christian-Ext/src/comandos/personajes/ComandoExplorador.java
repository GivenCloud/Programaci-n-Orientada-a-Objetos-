package comandos.personajes;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import comandos.estructura.Direccion;
import comandos.estructura.Posicion;

public class ComandoExplorador extends Comando{
	
	private HashSet <Posicion> posicionesExploradas;
	private final LocalDateTime tiempo;

	public ComandoExplorador(int numBombas) {
		super(numBombas);
		posicionesExploradas = new HashSet <Posicion>();
		tiempo = LocalDateTime.now();
	}

	public boolean lanzarBomba() {
		if (ChronoUnit.SECONDS.between(tiempo, LocalDateTime.now()) > 10) {
			if (getEscenario().tieneVentana(getPosActual().getX(), getPosActual().getY()) && getBombasDisponibles() > 0) {
				bombasDisponibles--;
				getEscenario().liberarBomba(getPosActual());
				return true;
			} 
		}
		return false;
	}

	public Direccion movimiento() {
		List<Direccion> p = getEscenario().posiblesDirecciones(getPosActual().getX(), getPosActual().getY());
		LinkedList<Direccion> posiblesDirecciones = new LinkedList<>(p);
		Direccion dir = null;
		for (int i = 0; i < posiblesDirecciones.size(); i++) {
			if (!posicionesExploradas.contains(getPosActual().adyacente(posiblesDirecciones.get(i)))) {
				dir = posiblesDirecciones.get(i);
				posicionesExploradas.add(getPosActual().adyacente(posiblesDirecciones.get(i)));
				return dir;
			}
		}
		
		Random r = new Random();
		int random = r.nextInt(posiblesDirecciones.size());
		for (int i = 0; i < posiblesDirecciones.size(); i++) {
			if (random == i) {
				dir = posiblesDirecciones.get(i);
				return dir;
			}
		}
		return null;
	}
	
	@Override
	public ComandoExplorador clone() {
		ComandoExplorador copia = (ComandoExplorador) super.clone();
		copia.bombasDisponibles = 3;
		return copia;
		
	}
	
	public String getRuta() {
		return "imagenes/comando-explorador.png";
	}

}
