package comandos.personajes;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import comandos.estructura.Direccion;

public class ComandoMAK extends Comando {

	public ComandoMAK(int numBombas) {
		super(numBombas);
	}

	public boolean lanzarBomba() {
		if (getEscenario().tieneVentana(getPosActual().getX(), getPosActual().getY()) && getBombasDisponibles() > 0) {
			getEscenario().liberarBomba(getPosActual());
			bombasDisponibles--;
			return true;
		} else {
			return false;
		}
	}

	public Direccion movimiento() {
		List<Direccion> p = getEscenario().posiblesDirecciones(getPosActual().getX(), getPosActual().getY());
		LinkedList<Direccion> posiblesDirecciones = new LinkedList<>(p);
		Random r = new Random();
		int random = r.nextInt(posiblesDirecciones.size());
		Direccion dir = null;
		for (int i = 0; i < posiblesDirecciones.size(); i++) {
			if (random == i) {
				dir = posiblesDirecciones.get(i);
				return dir;
			}
		}
		return null;
	}
	
	@Override
	public ComandoMAK clone() {
		ComandoMAK copia = (ComandoMAK) super.clone();
		copia.bombasDisponibles = 3;
		return copia;
		
	}
	
	public String getRuta() {
		return "imagenes/comando-MAK.png";
	}

}
