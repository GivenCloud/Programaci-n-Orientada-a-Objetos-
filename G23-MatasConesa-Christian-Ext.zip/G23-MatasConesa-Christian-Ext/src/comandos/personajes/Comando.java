package comandos.personajes;

import comandos.estructura.Direccion;
import comandos.estructura.Escenario;
import comandos.estructura.Posicion;

public abstract class Comando implements Cloneable{
	private Posicion posActual;  
	private Escenario escenario;
	private final int numBombas;
	protected int bombasDisponibles;
	
	public Comando(int numBombas) {
		this.posActual = null;
		this.escenario = null;
		this.numBombas = numBombas;
		this.bombasDisponibles = numBombas;
	}
	
	public Escenario getEscenario() {
		return escenario;
	}
	
	public void setEscenario(Escenario escenario) {
		this.escenario = escenario;
	}
	
	public Posicion getPosActual() {
		return posActual;
	}

	public void setPosActual(Posicion posActual) {
		this.posActual = posActual;
	}

	public int getNumBombas() {
		return numBombas;
	}

	public int getBombasDisponibles() {
		return bombasDisponibles;
	}	

	public abstract boolean lanzarBomba();
	public abstract Direccion movimiento();
	public abstract String getRuta();
	
	private Comando copiaSuperficial() {
		try {
			Comando copiaSuperficial = (Comando) super.clone();
			return copiaSuperficial;
		} catch (CloneNotSupportedException e) {
			// No sucede si en la cabecera de la clase
			// indicamos "implements Cloneable"
			System.err.println("La clase no es cloneable");
		}
		return null; // no se ha podido obtener la copia
	}

	@Override
	public Comando clone() {
		Comando copia = copiaSuperficial();
		copia.bombasDisponibles = 3;
		return copia;
	}
}
