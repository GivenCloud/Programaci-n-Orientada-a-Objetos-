package comandos.juego;

public class Imagen {

	private final int x;
	private final int y;
	private final String ruta;
	
	public Imagen(int x, int y, String ruta) {
		this.x = x;
		this.y = y;
		this.ruta = ruta;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public String getRuta() {
		return ruta;
	}

	@Override
	public String toString() {
		return "Imagen [x=" + x + ", y=" + y + ", ruta=" + ruta + "]";
	}
		
}
