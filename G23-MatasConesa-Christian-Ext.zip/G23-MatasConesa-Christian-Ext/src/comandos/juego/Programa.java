package comandos.juego;

import java.awt.Color;

import comandos.estructura.Escenario;
import comandos.estructura.Direccion;
import comandos.estructura.Estado;
import comandos.estructura.Posicion;
import comandos.personajes.*;
import comandos.vista.Alarma;
import comandos.vista.Pantalla;

public class Programa {
	
	private static final int ANCHO = 5;
	private static final int ALTO = 9;
	private static final int ANCHO_CUADRO = 75;
	private static final Color COLOR_FONDO = Color.BLUE;
	private final static int ESPERA = 150;
	private static final String TECLA_ARRIBA = "w";
	private static final String TECLA_IZQUIERDA = "a";
	private static final String TECLA_ABAJO = "s";
	private static final String TECLA_DERECHA = "d";
	private static final String TECLA_X = "x";
	private static final String TECLA_P = "p";
	
	
	public static void main(String[] args) {
		
		int contadorMs = 0;
		Pantalla pantalla = new Pantalla(ANCHO, ALTO, ANCHO_CUADRO, COLOR_FONDO);
		
		Escenario escenario = new Escenario(ANCHO, ALTO, "a");
		ComandoAlfa comando1 = new ComandoAlfa(3);
		ComandoExplorador comando2 = new ComandoExplorador(3);
		ComandoMAK comando3 = new ComandoMAK(3);
	
		escenario.introducirComando(comando1);
		escenario.introducirComando(comando2);
		escenario.introducirComando(comando3);
		
		boolean fin = false;
		escenario.iniciarPartida();
		while (!fin) {
			Posicion posicion = escenario.getArma();

			// SondeoD
			if (pantalla.hayTecla()) {
				String tecla = pantalla.leerTecla();

				switch (tecla) {
				case TECLA_ARRIBA:
					escenario.desplazarObjetivo(Direccion.ARRIBA);
					break;
				case TECLA_ABAJO:
					escenario.desplazarObjetivo(Direccion.ABAJO);
					break;
				case TECLA_IZQUIERDA:
					escenario.desplazarObjetivo(Direccion.IZQUIERDA);
					break;
				case TECLA_DERECHA:
					escenario.desplazarObjetivo(Direccion.DERECHA);
					break;
				case TECLA_X:
					fin = true;
				case TECLA_P:
					escenario.disparar(posicion);
				}
			}

			pantalla.resetear(); 
			
			for (Imagen imagen : escenario.getImagenes()) {
				pantalla.addImagen(imagen.getX(), imagen.getY(), imagen.getRuta());
			}
			
			pantalla.addImagen(escenario.getArma().getX(), escenario.getArma().getY(), "imagenes/objetivo.png");
			pantalla.dibujar();
			
			String estado = "Tiempo: " + escenario.tiempoTotal() + " segundos";
			Alarma.dormir(ESPERA);
			contadorMs = contadorMs + ESPERA;

			if (contadorMs >= 1000) {
				escenario.actualizar();
				contadorMs = 0;
			}
			
			if (escenario.getEstado() != Estado.EN_JUEGO) {
				fin = true;
			}
			
			pantalla.setBarraEstado(estado);
		}
		pantalla.setBarraEstado("Fin de juego");
	}
}
