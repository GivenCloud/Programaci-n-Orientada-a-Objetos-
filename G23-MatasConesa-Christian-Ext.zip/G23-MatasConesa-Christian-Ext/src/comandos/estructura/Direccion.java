package comandos.estructura;

public enum Direccion {
	ARRIBA,
	DERECHA,
	ABAJO,
	IZQUIERDA
}

//Direccion dir = Direccion.ARRIBA; ACCEDO A ARRIBA
