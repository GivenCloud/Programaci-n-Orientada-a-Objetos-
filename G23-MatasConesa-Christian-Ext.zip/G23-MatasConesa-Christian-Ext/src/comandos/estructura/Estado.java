package comandos.estructura;

public enum Estado {
	EN_JUEGO,
	FIN_POR_BOMBA,
	FIN_POR_CONTROL
}
