package ejercicio3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * 
 * Una piscina es un lugar en el que se necesita una reserva previa para poder acceder.
 *
 */
public abstract class Piscina {
	private final String id;
	private final int aforo;
	private double porcentajeAforo;
	static final int PORCENTAJE_AFORO_POR_DEFECTO = 1;
	protected int capacidad;
	protected LinkedList<Reserva> reservas;
	protected HashMap<FranjaHoraria, Integer> mapaOcupacion;

	/**
	 * Constructor que inicializa la piscina tomando una id y un aforo.
	 * @param id cadena de carácteres que identifica la piscina
	 * @param aforo número máximo de personas que caben en la piscina
	 */
	public Piscina(String id, int aforo) {
		this.id = id;
		this.aforo = aforo;
		this.porcentajeAforo = PORCENTAJE_AFORO_POR_DEFECTO;
		this.capacidad = (int) (aforo * this.porcentajeAforo);
		this.reservas = new LinkedList<Reserva>();
		this.mapaOcupacion = new HashMap<FranjaHoraria, Integer>();
	}

	/**
	 * Método de consulta de la propiedad reservas.
	 * @return la lista de reservas hechas
	 */
	public List<Reserva> getReservas() {
		return Collections.unmodifiableList(this.reservas);
	}

	/**
	 * Método de consulta la propiedad id.
	 * @return el identificador de la piscina
	 */
	public String getId() {
		return id;
	}

	/**
	 * Método de consulta de la propiedad aforo.
	 * @return el número máximo de personas que caben en la piscina 
	 */
	public int getAforo() {
		return aforo;
	}

	/**
	 * Método de consulta de la propiedad porcentajeAforo.
	 * @return el porcentaje del aforo que puede entrar en la piscina (0-1)
	 */
	public double getPorcentajeAforo() {
		return porcentajeAforo;
	}

	/**
	 * Método de consulta de la propiedad porcentaje_aforo_por_defecto.
	 * @return el porcentaje por defecto del aforo que puede entrar en la piscina (1)
	 */
	public static int getPorcentajeAforoPorDefecto() {
		return PORCENTAJE_AFORO_POR_DEFECTO;
	}

	/**
	 * Método de consulta de la propiedad capacidad.
	 * @return número de personas que pueden acceder a la piscina
	 */
	public int getCapacidad() {
		return capacidad;
	}

	/**
	 * Método de consulta de la propiedad mapaOcupacion.
	 * @return mapa que asocia cada franja horaria con el nñumero de plazas reservadas
	 */
	public Map<FranjaHoraria, Integer> getMapaOcupacion() {
		return Collections.unmodifiableMap(mapaOcupacion);
	}

	/**
	 * Método de establecimiento de la propiedad porcentajeAforo.
	 * @param porcentaje nuevo porcentaje de la piscina 
	 */
	public void setPorcentajeAforo(double porcentaje) {
		this.porcentajeAforo = porcentaje;
		this.capacidad = (int) (aforo * this.porcentajeAforo);
	}

	/**
	 * Método de consulta de la cantidad de plazas reservadas en una franja horaria.
	 * @param franja franja horaria que se quiere consultar
	 * @return cantidad de plazas reservadas en esa franja horaria
	 */
	public int consultarPlazasReservadas(FranjaHoraria franja) {
		return mapaOcupacion.getOrDefault(franja, 0);
	}

	/**
	* Método de consulta de la cantidad de plazas libres en una franja horaria.
	 * @param franja franja horaria que se quiere consultar
	 * @return cantidad de plazas libres en esa franja horaria
	 */
	public int consultarPlazasLibres(FranjaHoraria franja) {
		return capacidad - consultarPlazasReservadas(franja);
	}

	/**
	 * Método para obtener todas las reservas vigentes de un usuario.
	 * @param usuario usuario que se quiere revisar
	 * @return lista con todas las reservas vigentes del usuario
	 */
	public List<Reserva> consultarReservas(Usuario usuario) {
		LinkedList<Reserva> reservasUsuario = new LinkedList<Reserva>();
		for (Reserva reserva : reservas) {
			LocalDate fecha = reserva.getFranjaHoraria().getFecha();
			if (reserva.getUsuario() == usuario && fecha.isAfter(LocalDate.now().plusMonths(1))) {
				reservasUsuario.add(reserva);
			}
		}
		return Collections.unmodifiableList(reservasUsuario);
	}

	/**
	 * Método abstracto para reservar.
	 * @param usuario usuario que realiza la reserva
	 * @param franjaHoraria franja horaria en la que se quiere reservar
	 * @param numPlazas número de personas que se reservan
	 * @return devuelve true si la reserva fue posible y false en caso contrario
	 */
	public abstract boolean reservar(Usuario usuario, FranjaHoraria franjaHoraria, int numPlazas);

	/**
	 * Método abstracto sobrecargado para reservar en la fecha actual.
	 * @param usuario usuario que realiza la reserva
	 * @param hora hora en la que se quiere reservar
	 * @param numPlazas número de personas que se reservan
	 * @return devuelve true si la reserva fue posible y false en caso contrario
	 */
	public abstract boolean reservar(Usuario usuario, int hora, int numPlazas); // La fecha es la actual

	/**
	 * Método que comprueba si un usuario tiene una reserva y puede acceder a la piscina.
	 * @param usuario usuario que realizó la reserva
	 * @param numPersonasGrupo número de personas que se reservaron
	 * @return devuelve true si puede acceder a la piscina y false en caso contrario
	 */
	public boolean accederPiscina(Usuario usuario, int numPersonasGrupo) {
		for (Reserva reserva : reservas) {
			if (reserva.getUsuario() == usuario && reserva.getFranjaHoraria().getFecha() == LocalDate.now()
					&& reserva.getFranjaHoraria().getHora() == LocalDateTime.now().getHour()
					&& reserva.getPlazas() >= numPersonasGrupo) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Está operación cancela todas las reservas vigentes de un usuario.
	 * @param usuario usuario al que se le van a cancelar todas sus reservas vigentes
	 */
	public void cancelarReservas(Usuario usuario) { // Elimina las reservas de un usuario a partir de mañana y actualiza el mapa
		List<Reserva> reservasUsuario = consultarReservas(usuario); 
		for (Reserva reserva : reservasUsuario) {
			int valor = mapaOcupacion.get(reserva.getFranjaHoraria()) - reserva.getPlazas();
			mapaOcupacion.put(reserva.getFranjaHoraria(), valor);
			reservas.remove(reserva);
		}

	}
	
	private Piscina copiaSuperficial() {
		try {
			Piscina copiaSuperficial = (Piscina) super.clone();
			return copiaSuperficial;
		} catch (CloneNotSupportedException e) {
			// No sucede si en la cabecera de la clase
			// indicamos "implements Cloneable"
			System.err.println("La clase no es cloneable");
		}
		return null; // no se ha podido obtener la copia
	}

	@Override
	public Piscina clone() {
		Piscina copia = copiaSuperficial();
		copia.reservas = new LinkedList<>(this.reservas);
		copia.mapaOcupacion = new HashMap<>(this.mapaOcupacion);
		return copia;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return getClass().getName() + " [id=" + id + ", aforo=" + aforo + ", porcentajeAforo=" + porcentajeAforo
				+ ", capacidad=" + capacidad + ", reservas=" + reservas + ", mapaOcupacion=" + mapaOcupacion + "]";
	}

}
