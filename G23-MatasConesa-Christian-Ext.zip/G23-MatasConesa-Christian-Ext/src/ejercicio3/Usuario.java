package ejercicio3;

import java.util.Objects;

/**
 * 
 * Un usuario es una persona que quiere acceder a una piscina
 *
 */
public class Usuario {
	private final String nombre;
	private final int dni;
	
	/**
	 * Constructor que inicializa un usuario tomando su nombre y su dni.
	 * @param nombre cadena que representa un posible valor para identificar al usuario
	 * @param dni enteros que pueden ser otro posible valor para identidicar a un usuario
	 */
	public Usuario(String nombre, int dni) {
		super();
		this.nombre = nombre;
		this.dni = dni;
	}
	
	/**
	 * Método de consulta de la propiedad nombre.
	 * @return el nombre de ese usuario
	 */
	public String getNombre() {
		return nombre;
	}
	
	/**
	 * Método de consulta de la propiedad dni.
	 * @return el dni de ese usuario
	 */
	public int getDni() {
		return dni;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		return dni == other.dni;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", dni=" + dni + "]";
	}
	
	
}
