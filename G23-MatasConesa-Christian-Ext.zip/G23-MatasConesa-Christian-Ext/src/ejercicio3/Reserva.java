package ejercicio3;

/**
 * 
 * Una reserva representa la petición de un usuario para acceder a una piscina
 *
 */
public class Reserva {
	private final Usuario usuario;
	private final int plazas;
	private final FranjaHoraria franjaHoraria;

	/**
	 * Constructor que inicializa la reserva tomando un usuario, las plazas que 
	 * quiere reservar y la franja horaria en la que se quiere realizar la reserva.
	 * @param usuario usuario que realiza la reserva
	 * @param plazas número de personas que se reservan
	 * @param franjaHoraria fecha y hora en la que tiene lugar la reserva
	 */
	public Reserva(Usuario usuario, int plazas, FranjaHoraria franjaHoraria) {
		this.usuario = usuario;
		this.plazas = plazas;
		this.franjaHoraria = franjaHoraria;
	}

	/**
	 * Método de consulta de la propiedad usuario.
	 * @return el usuario que ha relizado la reserva
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * Método de consulta de la propiedad plazas.
	 * @return el número de plazas reservadas
	 */
	public int getPlazas() {
		return plazas;
	}

	/**
	 * Método de consulta de la propiedad franja horaria.
	 * @return la franja horaria en la que se realizó la reserva
	 */
	public FranjaHoraria getFranjaHoraria() {
		return franjaHoraria;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return "Reserva [usuario=" + usuario + ", plazas=" + plazas + ", franjaHoraria=" + franjaHoraria + "]";
	}

}
