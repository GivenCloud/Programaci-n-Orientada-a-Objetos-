package ejercicio3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * 
 * Una piscina pública es un tipo de piscina que solo está disponible entre julio y agosto 
 * en ciertas horas, además es menos restrictiva que la comunitaria en cuanto a acceso.
 *
 */
public class PiscinaPublica extends Piscina implements Cloneable {
	private int horaApertura;
	private int horaCierre;

	/**
	 * Constructor que inicializa la piscina pública tomando un id y un aforo
	 * @param id cadena de carácteres que identifica la piscina
	 * @param aforo número máximo de personas que caben en la piscina
	 */
	public PiscinaPublica(String id, int aforo) {
		super(id, aforo);
		this.horaApertura = 8;
		this.horaCierre = 22;
	}

	/**
	 * Método de consulta de la hora de apertura de la piscina.
	 * @return un entero que representa la hora a la que la piscina abre
	 */
	public int getHoraApertura() {
		return horaApertura;
	}

	/**
	 * Método de establecimiento de la propiedad horaApertura.
	 * @param horaApertura nueva hora a la que abre la piscina
	 */
	public void setHoraApertura(int horaApertura) {
		this.horaApertura = horaApertura;
	}

	/**
	 * Método de consulta de la hora de cierre de la piscina.
	 * @return un entero que representa la hora a la que la piscina cierra
	 */
	public int getHoraCierre() {
		return horaCierre;
	}

	/**
	 * Método de establecimiento de la propiedad horaCierre.
	 * @param horaCierre nueva hora a la que cierra la piscina
	 */
	public void setHoraCierre(int horaCierre) {
		this.horaCierre = horaCierre;
	}

	/**
	 * Método para reservar, consiste en comprobar si la franja horaria es válida, si lo es 
	 * se comprueba que la piscina tenga al menos las mismas plazas libres que las que el 
	 * usuario está reservando.
	 */
	@Override
	public boolean reservar(Usuario usuario, FranjaHoraria franjaHoraria, int numPlazas) {
		if (franjaHoraria.getFecha().getMonthValue() >= Month.JULY.getValue()
				&& franjaHoraria.getFecha().getMonthValue() <= Month.AUGUST.getValue()
				&& franjaHoraria.getHora() >= horaApertura && franjaHoraria.getHora() <= horaCierre) {
			if (consultarPlazasLibres(franjaHoraria) >= numPlazas) {
				Reserva reserva = new Reserva(usuario, numPlazas, franjaHoraria);
				reservas.add(reserva);
				int valor = mapaOcupacion.getOrDefault(franjaHoraria, 0) + numPlazas;
				mapaOcupacion.put(franjaHoraria, valor);
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * Método sobrecargado para reservar, este toma la fecha actual.
	 */
	@Override
	public boolean reservar(Usuario usuario, int hora, int numPlazas) {
		if (LocalDate.now().getMonthValue() >= Month.JULY.getValue()
				&& LocalDate.now().getMonthValue() <= Month.AUGUST.getValue() && hora >= horaApertura
				&& hora <= horaCierre) {
			FranjaHoraria franjaHoraria = new FranjaHoraria(LocalDate.now(), hora);
			if (consultarPlazasLibres(franjaHoraria) >= numPlazas) {
				Reserva reserva = new Reserva(usuario, numPlazas, franjaHoraria);
				reservas.add(reserva);
				int valor = mapaOcupacion.getOrDefault(franjaHoraria, 0) + numPlazas;
				mapaOcupacion.put(franjaHoraria, valor);
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * Método sobrecargado para comprobar si un usuario puede acceder a la piscina, este es menos restrictivo,
	 * porque si el usuario no tiene reserva, pero hay suficientes plazas libres, se genera una reserva en ese momento
	 * y el usuario puede acceder a la piscina.
	 */
	public boolean accederPiscina(Usuario usuario, int numPersonasGrupo) {
		for (Reserva reserva : reservas) {
			if (reserva.getUsuario() == usuario && reserva.getFranjaHoraria().getFecha() == LocalDate.now()
					&& reserva.getFranjaHoraria().getHora() == LocalDateTime.now().getHour()
					&& reserva.getPlazas() >= numPersonasGrupo) {
				return true;
			}
		}
		FranjaHoraria franjaHoraria = new FranjaHoraria(LocalDate.now(), LocalTime.now().getHour());
		if (consultarPlazasLibres(franjaHoraria) >= numPersonasGrupo) {
			reservar(usuario, LocalTime.now().getHour(), numPersonasGrupo);
			return true;
		}
		return false;
	}

	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return super.toString() + " [horaApertura=" + horaApertura + ", horaCierre=" + horaCierre + "]";
	}

	@Override
	public PiscinaPublica clone() {
		PiscinaPublica copia = (PiscinaPublica) super.clone();
		copia.reservas = new LinkedList<>(this.reservas);
		copia.mapaOcupacion = new HashMap<>(this.mapaOcupacion);
		return copia;
	}

}
