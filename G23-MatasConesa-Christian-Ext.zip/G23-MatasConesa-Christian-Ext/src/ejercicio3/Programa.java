package ejercicio3;

import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedList;

public class Programa {
	public static void main(String[] args) {
		
		Usuario usuario1 = new Usuario("Pedro", 1);
		Usuario usuario2 = new Usuario("Pablo", 2);
		Usuario usuario3 = new Usuario("Daniel", 3);
		Usuario usuario4 = new Usuario("David", 4);
		Usuario usuario5 = new Usuario("Jorge", 5);
		Usuario usuario6 = new Usuario("Lucía", 6); //Usuario propietario
		Usuario usuario7 = new Usuario("María", 7); //Usuario propietario
		Usuario usuario8 = new Usuario("Marta", 8); //Usuario propietario
		
		FranjaHoraria franjaHoraria1 = new FranjaHoraria(LocalDate.of(2023, 7, 16), 18); //Válida
		FranjaHoraria franjaHoraria2 = new FranjaHoraria(LocalDate.of(2023, 9, 1), 18); //No válida
		
		PiscinaComunitaria piscinaComunitaria = new PiscinaComunitaria("PC", 10);
		PiscinaPublica piscinaPublica = new PiscinaPublica("PP", 10);
		
		LinkedList<Piscina> piscinas = new LinkedList<Piscina>();
		Collections.addAll(piscinas, piscinaComunitaria, piscinaPublica);
		
		for (Piscina piscina : piscinas) {
			piscina.setPorcentajeAforo(0.8);
			if (piscina instanceof PiscinaComunitaria) {
				((PiscinaComunitaria) piscina).darseDeAlta(usuario6, usuario7, usuario8);
			}
		}
		
		//Reservas
		for (Piscina piscina : piscinas) {
			piscina.reservar(usuario8, franjaHoraria1, 3); //Válido en ambas piscinas
			piscina.reservar(usuario5, franjaHoraria1, 2); //Válido en la piscina pública (una reserva de un usuario no propietario)
			piscina.reservar(usuario4, franjaHoraria2, 3); //No es válido en ninguna (reserva el 1 de septiembre)
			piscina.reservar(usuario8, franjaHoraria1, 1); //No válido en la piscina comunitaria (ya tiene una reserva vigente)
		}
		
		for (Piscina piscina : piscinas){
			for (Reserva reserva : piscina.getReservas()) {
				System.out.println(reserva.toString());
			}
		}
		
		Piscina copia1 = (piscinas.getFirst()).clone();
		Piscina copia2 = (piscinas.getLast()).clone();
		
		LinkedList<Piscina> copiasSeguridad = new LinkedList<Piscina>();
		Collections.addAll(copiasSeguridad, copia1, copia2);
		
		for (Piscina piscina : copiasSeguridad) {
			System.out.println(piscina.toString());
		}
		
		System.out.println("FIN DEL PROGRAMA.");
	}
}
