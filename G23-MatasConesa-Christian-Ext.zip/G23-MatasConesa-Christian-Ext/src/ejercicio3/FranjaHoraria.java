package ejercicio3;

import java.time.LocalDate;
import java.util.Objects;


/**
 * 
 * Una franja horaria sirve para representar la fecha y hora en la que un usuario realiza una reserva.
 *
 */
public class FranjaHoraria {
	private final LocalDate fecha;
	private final int hora;

	/**
	 * Constructor que inicializa la franja horaria tomando una fecha y una hora.
	 * @param fecha día, mes y año en el que tiene lugar
	 * @param hora 
	 */
	public FranjaHoraria(LocalDate fecha, int hora) {
		this.fecha = fecha;
		this.hora = hora;
	}

	/**
	 * Versión sobrecargada del constructor que inicializa la franja a la fecha actual y tomando una hora.
	 * @param hora
	 */
	public FranjaHoraria(int hora) {
		this(LocalDate.now(), hora);
	}

	/**
	 * Método de consulta de la propiedad fecha.
	 * @return la fecha de la franja horaria
	 */
	public LocalDate getFecha() {
		return fecha;
	}

	/**
	 * Método de consulta de la propiedad hora.
	 * @return la hora de la franja horaria
	 */
	public int getHora() {
		return hora;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return Objects.hash(fecha, hora);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FranjaHoraria other = (FranjaHoraria) obj;
		return Objects.equals(fecha, other.fecha) && hora == other.hora;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return "FranjaHoraria [fecha=" + fecha + ", hora=" + hora + "]";
	}
	
	
}
