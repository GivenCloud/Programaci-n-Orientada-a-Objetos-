package ejercicio3;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 
 * Una piscina comunitaria es un tipo de piscina en la que solo pueden hacer reservas 
 * usuarios que son propietarios registrados.
 *
 */
public class PiscinaComunitaria extends Piscina implements Cloneable{
	private HashSet<Usuario> propietarios;

	/**
	 * Constructor que inicializa la piscina comunitaria tomando un id y un aforo.
	 * @param id cadena de carácteres que identifica la piscina
	 * @param aforo número máximo de personas que caben en la piscina
	 */
	public PiscinaComunitaria(String id, int aforo) {
		super(id, aforo);
		this.propietarios = new HashSet<Usuario>();
	}

	/**
	 * Método de consulta de la propiedad propietarios.
	 * @return el conjunto de usuario propietarios
	 */
	public Set<Usuario> getPropietarios() {
		return Collections.unmodifiableSet(propietarios);
	}

	/**
	 * Método para darse de alta como usuario propietario
	 * @param usuarios argumento variable, son todos los usuarios que se registran como propietarios
	 */
	public void darseDeAlta(Usuario... usuarios) {
		for (int i = 0; i < usuarios.length; i++) {
			propietarios.add(usuarios[i]);
		}
	}

	/**
	 * Método para darse de baja como usuario propietario
	 * @param usuario usuario que deja de ser propietario
	 */
	public void darseDeBaja(Usuario usuario) {
		propietarios.remove(usuario);
		cancelarReservas(usuario);
	}

	
	/**
	 * Método para reservar, consiste en comprobar si el usuario es propietario, si lo es 
	 * se comprueba que no tenga otras reservas vigentes, después se comprueba que la 
	 * piscina tenga al menos las mismas plazas libres que las que el usuario está reservando.
	 */
	@Override
	public boolean reservar(Usuario usuario, FranjaHoraria franjaHoraria, int numPlazas) {
		if (propietarios.contains(usuario)) {
			List<Reserva> reservasUsuario = consultarReservas(usuario);
			if (!reservasUsuario.isEmpty()) {
				return false;
			}
			
			if (consultarPlazasLibres(franjaHoraria) >= numPlazas) {
				Reserva reserva = new Reserva(usuario, numPlazas, franjaHoraria);
				reservas.add(reserva);
				int valor = mapaOcupacion.getOrDefault(franjaHoraria, 0) + numPlazas;
				mapaOcupacion.put(franjaHoraria, valor);
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * Método sobrecargado para reservar, este toma la fecha actual.
	 */
	@Override
	public boolean reservar(Usuario usuario, int hora, int numPlazas) { // La fecha es la actual
		if (propietarios.contains(usuario)) {
			List<Reserva> reservasUsuario = consultarReservas(usuario);
			if (!reservasUsuario.isEmpty()) {
				return false;
			}

			FranjaHoraria franjaHoraria = new FranjaHoraria(LocalDate.now(), hora);
			if (consultarPlazasLibres(franjaHoraria) >= numPlazas) {
				Reserva reserva = new Reserva(usuario, numPlazas, franjaHoraria);
				reservas.add(reserva);
				int valor = mapaOcupacion.getOrDefault(franjaHoraria, 0) + numPlazas;
				mapaOcupacion.put(franjaHoraria, valor);
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		return super.toString() + " [propietarios=" + propietarios + "]";
	}

	@Override
	public PiscinaComunitaria clone() {
		PiscinaComunitaria copia = (PiscinaComunitaria) super.clone();
		copia.propietarios = new HashSet<>(this.propietarios);
		return copia;
	}

}
